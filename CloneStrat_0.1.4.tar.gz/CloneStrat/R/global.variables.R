globalVariables(c("ID",".","vaf","pred","marker","pos","SIN","metric"))
