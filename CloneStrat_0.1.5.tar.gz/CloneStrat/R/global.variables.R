globalVariables(c("ID",".","vaf","pred","marker","pos","SIN","metric", "data.vcf",
                  "avg.logR", "avg.Imb", "segment"))
