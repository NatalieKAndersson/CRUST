##-------------------------------------------------
#'Copynumber estimation
#'
#'NGS probes are extracted rom a vcfR object, scaled and bias corrected to optimize estimatio
#'of allelelic composition. This function can handle only a combination of one tumor sample with
#'a matched normal sample. Analysis is performed using the package \code{\link{falcon}}
#'
#'@param data A \code{vcfR} object with one normal and one tumor sample. The \emph{AD} element
#'of the \emph{FORMAT} field is a manadatory input
#'@param AD a \code{character} deoning \emph{ID} for depth of the reference allele.
#'@param file.name A \code{character} string. this name will be used to save the scaled and unscaled
#'relative coverage plot along with the final copy number estimate plot in the working directory
#'@param uniform.break A numeric value signifying fixed length of the genomic window. Each window
#'is considered as distinct chromosomal segment with edges being the break points for copy number
#'estimation.
#'
#'@return A list of two data frames that is further used to obtain the allelic segmentation plot
#'
#'@details This function uses \code{\link{falcon}} to estimate allele specific copy number of all
#'sequeneced probes. Subsequently sliding window algorithm is used to generate chromosomal segments 
#'with precicted distinct copynumbers. The relative coverages are sclaed with GC content of the binned
#'windows 
#'@seealso \href{https://doi.org/10.1093/nar/gks001}{Benjamini \emph{et al}., 2012} 
#'with a loess regression \code{\link{loess}}.

CopySeg_falcon<- function(data, AD, file.name, uniform.break){
  seq<-data.prep(x=data, AD=AD)
  seq.genome<-allele.munge(x=seq)
  seq.genome.fix<-allele.summary(x=seq.genome, filename = file.name)
  if (missing(uniform.break)){
    segments<-CN.summary(x=seq.genome.fix, filename = file.name)
  } else {
    segments<-CN.summary(x=seq.genome.fix, filename = file.name, uniform.break = uniform.break)
  }
  return(list(segments,seq.genome.fix))
}

##-------------------------------------------------
#Extracting allele frequencies from tumor and normal samples
#The vcfR file must ave the AD FORMAT input
#Adding chromosome, base pair position and reference allele, also
#performing general quality control steps
data.prep<-function(x, AD){
  ad <- as.data.frame(extract.gt(x,  element = AD)) #Approx read depth
  ad.normal.tmp<-unlist(strsplit(as.character(ad[,1]),split="[,]"))
  ad.tumor.tmp<-unlist(strsplit(as.character(ad[,2]),split="[,]"))
  ref.normal.tmp<-as.numeric(ad.normal.tmp[c(TRUE,FALSE)])
  alt.normal.tmp<-as.numeric(ad.normal.tmp[c(FALSE,TRUE)])
  ref.tumor.tmp<-as.numeric(ad.tumor.tmp[c(TRUE,FALSE)])
  alt.tumor.tmp<-as.numeric(ad.tumor.tmp[c(FALSE,TRUE)])
  seq<-data.frame(cbind(ref.normal.tmp,alt.normal.tmp,ref.tumor.tmp,alt.tumor.tmp))
  rm(list=ls()[grep("tmp",ls())])
  colnames(seq) <- c('AN','BN','AT','BT')
  seq$chromosome<-noquote(getCHROM(data.vcf))
  seq$position<-as.numeric(getPOS(data.vcf))
  seq$base.ref<-noquote(getREF(data.vcf))
  seq <- subset(seq,seq$BT>10 & seq$BN>10 & seq$AT>10 & seq$AN>10)
  return(seq)
}

##-------------------------------------------------
#Calcularing B allele frequency and relaive coverage
#for the entire genome per probe
allele.munge<-function(x){
  seq.genome<-data.frame()
  for (i in 1:22){
    seq.chr<-subset(x,x$chromosome==as.character(i))
    ##ratio of median of unscaled tumor and normal total coverage
    Rdep<-median(seq.chr$AT+seq.chr$BT)/median(seq.chr$AN+seq.chr$BN)
    for (j in 1:nrow(seq.chr)){
      ##B-allele frequency
      seq.chr$Bf[j]<-seq.chr$BT[j]/(seq.chr$AT[j]+seq.chr$BT[j])
      ##Scaled R
      seq.chr$R[j]<-(seq.chr$AT[j]+seq.chr$BT[j])/(seq.chr$AN[j]+seq.chr$BN[j])/Rdep
    }
    ##Creating a merged data
    seq.genome<-rbind(seq.genome,seq.chr)
    rm(seq.chr)
  }
  return(seq.genome)
}

##-------------------------------------------------
#Rescaling relative coverage with loess regression
#correcting on GC content of the sequence reads.
#This function creates two plots for each chromosome.
#One for original covergae and the other for rescaled.
#The plot outputs are sunk in a file specified by filename.
allele.summary<-function(x, filename){
  cat("correcting for GC bias",date(),"\n")
  file = paste0(filename,"_GCcorrection.pdf")
  pdf(file)
  seq.genome.fix<-data.frame()
  ##progress bar as it is done chromosome wise
  pb <- txtProgressBar(min = 0, max = 22, style = 3)
  for (i in 1:22){
    seq.chr<-subset(x,x$chromosome==as.character(i))
    ##GC bias correction
    tmp<-GC.correction(seq.chr ,i=i)
    ##Create the main data with corrected R
    seq.genome.fix<-rbind(seq.genome.fix,tmp)
    Sys.sleep(0.1)
    setTxtProgressBar(pb, i)
    rm(seq.chr)
  }
  dev.off()
  ##Creating corrected logR
  seq.genome.fix$logR<-suppressWarnings(log2(seq.genome.fix$R.fix))
  return(seq.genome.fix)
}

##-------------------------------------------------
#Copynumber estimates are generated with falcon
#Plots of B allele frequencies, relative coverage and
#allele-specific copy number estimates are sunk in 
#pdf named with the filename iput
CN.summary<-function(x, filename, uniform.break){
  file = paste0(filename,"_CNprofile.pdf")
  pdf(file)
  segments<-data.frame()
  for (i in 1:22){
    seq.chr<-subset(x,x$chromosome==as.character(i))
    seq.chr[seq.chr==0] <- NA
    seq.chr <- na.omit(seq.chr)
    seq.chr <- subset(seq.chr,seq.chr$BT>10 & seq.chr$BN>10 & seq.chr$AT>10 & seq.chr$AN>10)
    if (missing(uniform.break)){
      break.len = NULL } else {
        break.len = get.breakpoints(seq.chr$position,window=uniform.break)
      }
    cn <- falcon::getASCN(seq.chr[,c('AN','BN','AT','BT','R.fix')], tauhat=break.len)
    if (missing(uniform.break)){
      view.falcon(cn,pos=as.numeric(seq.chr$position),i=i)
      tmp.pos<-c(min(seq.chr$position),seq.chr$position[cn$tauhat],max(seq.chr$position))
      chromosome<-seq.chr$chromosome[1:(length(cn$tauhat)+1)]
      start.pos<-(tmp.pos+1)[1:(length(cn$tau)+1)]
      end.pos<-tmp.pos[-1]
      segment.dat<-data.frame(chromosome,start.pos,end.pos)
      segment.dat$segment.length<-segment.dat$end.pos - segment.dat$start.pos
      tmp.cn<-cn$ascn
      #tmp.cn<-ceiling(cn$ascn)
      segment.dat$CNt<-tmp.cn[1,]+tmp.cn[2,]
      segment.dat$A<-tmp.cn[1,]
      segment.dat$B<-tmp.cn[2,]
      segment.dat$CN.profile<-paste(ceiling(tmp.cn[2,]),"+",ceiling(tmp.cn[1,]))
      segments<-rbind(segments,segment.dat)
      rm(list=ls()[grep("tmp",ls())])
    } else {
      real.length<-length(unique(break.len))
      tmp.pos<-seq.chr$position[c(1,unique(break.len))]
      chromosome<-seq.chr$chromosome[1:real.length]
      start.pos<-(tmp.pos)[1:real.length]
      end.pos<-tmp.pos[-1]
      segment.dat<-data.frame(chromosome,start.pos,end.pos)
      segment.dat$segment.length<-segment.dat$end.pos - segment.dat$start.pos
      segment.dat$cns1<-cn$ascn[1,]
      segment.dat$cns2<-cn$ascn[2,]
      segments<-rbind(segments,segment.dat)
    }
  }
  dev.off()
  return(segments)
}

#Centering the coverage ratio (R) on the unbalanced
#GC content
balancedCenter <- function(pos, numReads){
  center = 0
  netChange = sum((pos-center)*numReads)
  while(netChange > 0){
    center = center + 1
    netChange = sum((pos-center)*numReads)
  }
  
  #now zero in on zero (within 0.1%)
  margin = sum(numReads)*0.001
  adj = 0.5
  center = (center-1)+adj
  netChange = sum((pos-center)*numReads)
  while((abs(netChange) > margin) & (adj > 0)){
    adj = adj/2
    if(netChange > 0){
      center = center + adj
    }else{
      center = center - adj
    }
    netChange = sum((pos-center)*numReads)
  }
  return(center)
}

#Plotting the copy numbers
view.falcon <- function (output, pos = NULL, rdep = NULL, plot = "all", i, ...) {
  readMatrix = output$readMatrix
  tauhat = output$tauhat
  ascn = output$ascn
  AN = readMatrix$AN
  BN = readMatrix$BN
  AT = readMatrix$AT
  BT = readMatrix$BT
  Rf = as.numeric(readMatrix$R.fix)
  N = length(AT)
  tau = sort(unique(c(1, tauhat, N)))
  ascn1 = ascn[1, ]
  ascn2 = ascn[2, ]
  if (is.null(pos))
    pos = 1:N
  main.title = paste("Chromosome",i)
  myxlab = "Position (bp)"
  if (is.null(rdep)) 
    rdep = median(AT + BT)/median(AN + BN)
  if (plot == "all") {
    par(mfrow = c(3, 1))
  }
  if (plot == "all" || plot == "Afreq") {
    plot(pos, AN/(AN + BN), main = main.title, ylim = c(0, 1), 
         ylab = "A freq", col = "gray", pch = ".", 
         ...)
    points(pos, AT/(AT + BT), pch = ".", ...)
    abline(h = 0.5, col = "green")
    abline(v = pos[tau], col = "purple", lty = 4)
  }
  if (plot == "all" || plot == "RelativeCoverage") {
    #    if(is.null(Rf) == FALSE){
    plot(pos, Rf, ylab = "Relative Coverage", 
         xlab = myxlab, pch = ".", ...)
    abline(h = 1, col = "green")
    abline(v = pos[tau], col = "purple", lty = 4)
    #    } else {
    #      plot(pos, (AT + BT)/(AN + BN)/rdep, ylab = "Relative Coverage", 
    #           xlab = myxlab, pch = ".", ...)
    #      abline(h = 1, col = "green")
    #      abline(v = pos[tau], col = "purple", lty = 2)
    #    }
  }
  if (plot == "all" || plot == "ASCN") {
    falcon::view(output, pos = pos, plot="ASCN")
  }
}

#Getting 1Mb wide break points given a list of basepairs
#when uniform.break is meantioned in the wrapper function
get.breakpoints <- function(pos,window){
  l<-vector()
  tau<-c(seq(from=range(pos)[1], to=range(pos)[2], by=window), range(pos)[2])
  for (j in 2: length(tau)) {
    l<-c(l,which.min(abs(as.numeric(pos)-tau[j])))
  }
  return(l)
}

##============GC content scaling=============
GC.correction<- function(sequence, i){
  tumor<-sequence
  GC$pos<-paste0(GC$chr,":",GC$interval1,"-",GC$interval2)
  GC<-GC[,c(5,4)]
  window<-function(x){options(scipen=999);ceiling(x/10^4)*10^4}
  #Basepair positions has to be saved in the collumn name position
  interval.1<-window(tumor$position)
  #chromosomes has to be 1 to 22 integer saved in collumn name chromosome
  tumor$pos<-paste0('chr',tumor$chromosome,':',1+interval.1-10^4,"-",interval.1) 
  tumor<-dplyr::left_join(tumor,GC,by='pos')
  tumor$GC.percent<-ceiling(tumor$GC*100)
  tumor<-subset(tumor, select=-c(pos,GC))
  
  #Performing loes correction on the relative coverage
  #which needs to be saved as the collumn name R
  loessMod30 <- loess(R ~ GC.percent, data=tumor, span=0.3)
  bmed=balancedCenter(sort(unique(loessMod30$fitted)),as.numeric(table(loessMod30$fitted)))
  reads.adj = loessMod30$fitted-bmed
  tumor$R.fix = tumor$R-reads.adj
  loessMod30.fix <- loess(R.fix ~ GC.percent, data=tumor, span=0.3)
  plot(y=tumor$R, x=tumor$GC.percent, type="p", main=paste("Loess Smoothing and Prediction for chromosome ", i), 
       xlab="GC content percentage",
       ylab="relative coverage (R)",col="grey")
  points(loessMod30$fitted, x=tumor$GC.percent, pch= 16, col="blue")
  plot(y=tumor$R.fix, x=tumor$GC.percent, type="p",
       xlab="GC content percentage",
       ylab="Scaled relative coverage (R)",col="grey")
  points(loessMod30.fix$fitted, x=tumor$GC.percent, pch= 16, col="red")
  return(tumor)
}